document.addEventListener('DOMContentLoaded', () => {
    console.log("Main script.js loaded. Add general initializations if needed.");
    });